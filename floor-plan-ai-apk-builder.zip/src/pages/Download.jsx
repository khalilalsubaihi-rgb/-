export default function DownloadPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gradient-to-r from-indigo-900 to-indigo-800 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Advanced Application</h1>
          <p className="text-xl md:text-2xl opacity-90">
            Unlock the power of innovation with our cutting-edge solution
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-xl overflow-hidden">
            <div className="p-8 md:p-12">
              <h2 className="text-3xl font-bold text-indigo-900 mb-6">Download Now</h2>
              <p className="text-lg text-gray-600 mb-8">
                Experience the future of productivity with our advanced application. Download the version that fits your needs and start transforming your workflow today.
              </p>

              <div className="space-y-6">
                <div className="bg-indigo-50 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-indigo-900 mb-2">Windows</h3>
                  <p className="text-gray-600 mb-4">Version 4.2.1 (64-bit)</p>
                  <a
                    href="/download/windows"
                    className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200"
                  >
                    Download for Windows
                  </a>
                </div>

                <div className="bg-indigo-50 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-indigo-900 mb-2">macOS</h3>
                  <p className="text-gray-600 mb-4">Version 4.2.1 (Universal)</p>
                  <a
                    href="/download/macos"
                    className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200"
                  >
                    Download for macOS
                  </a>
                </div>

                <div className="bg-indigo-50 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-indigo-900 mb-2">Linux</h3>
                  <p className="text-gray-600 mb-4">Version 4.2.1 (Debian/Ubuntu)</p>
                  <a
                    href="/download/linux"
                    className="inline-block bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-6 rounded-lg transition duration-200"
                  >
                    Download for Linux
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-8 md:p-12 text-center">
              <h3 className="text-xl font-semibold text-indigo-900 mb-4">System Requirements</h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Our application requires a modern operating system and at least 4GB of RAM. For optimal performance, we recommend using the latest version of your operating system.
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-indigo-900 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-lg opacity-90">© 2023 Advanced Application. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}