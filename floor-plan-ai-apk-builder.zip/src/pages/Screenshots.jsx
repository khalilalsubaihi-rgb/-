export default function ScreenshotsPage() {
  const screenshots = [
    {
      id: 1,
      title: "Dashboard Overview",
      description: "Get a comprehensive view of your application's performance metrics and key indicators.",
      imageUrl: "https://via.placeholder.com/800x500/6200EE/FFFFFF?text=Dashboard+Overview"
    },
    {
      id: 2,
      title: "Advanced Analytics",
      description: "Dive deep into your data with our powerful analytics tools and visualization features.",
      imageUrl: "https://via.placeholder.com/800x500/6200EE/FFFFFF?text=Advanced+Analytics"
    },
    {
      id: 3,
      title: "User Management",
      description: "Efficiently manage user accounts, permissions, and access levels with our intuitive interface.",
      imageUrl: "https://via.placeholder.com/800x500/6200EE/FFFFFF?text=User+Management"
    },
    {
      id: 4,
      title: "Real-time Monitoring",
      description: "Monitor your application's performance in real-time and receive instant alerts for any issues.",
      imageUrl: "https://via.placeholder.com/800x500/6200EE/FFFFFF?text=Real-time+Monitoring"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold text-center text-gray-800 mb-12">
          Application Screenshots
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {screenshots.map((screenshot) => (
            <div
              key={screenshot.id}
              className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
            >
              <div className="h-64 overflow-hidden">
                <img
                  src={screenshot.imageUrl}
                  alt={screenshot.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-800 mb-2">
                  {screenshot.title}
                </h2>
                <p className="text-gray-600">{screenshot.description}</p>
                <div className="mt-4">
                  <button className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors duration-200">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}