// server/api.js

// Mock data in memory
const features = [
  {
    title: "Feature 1",
    description: "This is the first feature of the application.",
    icon: "icon1.png"
  },
  {
    title: "Feature 2",
    description: "This is the second feature of the application.",
    icon: "icon2.png"
  }
];

const screenshots = [
  {
    imageUrl: "screenshot1.png",
    caption: "This is the first screenshot of the application."
  },
  {
    imageUrl: "screenshot2.png",
    caption: "This is the second screenshot of the application."
  }
];

// Express-style handlers
const handlers = {
  getFeatures: (req, res) => {
    res.status(200).json(features);
  },

  getScreenshots: (req, res) => {
    res.status(200).json(screenshots);
  }
};

module.exports = handlers;