# Backend

Generated stub for sheba-landing-page. Run with `node server/index.js` after wiring an Express server.